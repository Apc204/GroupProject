$('#help-button').click(function () {
	$('#pop-up').toggle();
});