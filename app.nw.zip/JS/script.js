var IN = 1;
var FRONTIER = 2;
var OUT = 3;
var NORTH = 10;
var EAST = 11;
var SOUTH = 12;
var WEST = 13;

var mazeWidth = 20;
var mazeHeight = 20;

var newHeight = (mazeHeight*2)+1;
var newWidth = (mazeWidth*2)+1;
var startX = 1;
var startY = 1;
var endX = newWidth-2;
var endY = newHeight-2;
var start = [1,1];
var finish = [(2*mazeWidth)-1,(2*mazeHeight)-1];
var frontierList = [];
var primGrid = [];

var PASSAGE = 'O';
var WALL = 'X';



window.onload = function()
{
	console.log("1");
	var maze = generateMaze();
	drawMaze(maze);

	//console.log(maze);
	var jsonLayout = JSON.stringify(maze);
	var jsonMaze = {
		"layout": jsonLayout,
		"startpos" : {
			"x": startX,
			"y": startY
		},
		"robotpos" : {
			"x":startX,
			"y": startY
		},
		"robot-orientation":"NORTH",
		"finishpos" : {
			"x" : endX,
			"y" : endY
		} 
	};
	var prefix = "[MAZE]";
	var json = prefix.concat(JSON.stringify(jsonMaze));

	console.log(jsonMaze);
	// connectToSocket(json);
}



function connectToSocket(jsonMaze)
{
	 alert("WebSocket is supported by your Browser!");
	 // Let us open a web socket
	 var ws = new WebSocket("ws://192.168.0.8:8080");
	 ws.onopen = function()
	 {
	    // Web Socket is connected, send data using send()
	    ws.send(jsonMaze);
	    ws.send("STEP");
	    alert("Message is sent...");
	 };
	 ws.onmessage = function (evt) 
	 { 
	    var received_msg = evt.data;
	    alert("Message is received... " + evt.data);
	 };
	 ws.onclose = function()
	 { 
	    // websocket is closed.
	    alert("Connection is closed..."); 
	 };
}

function drawMaze(maze)
{
	console.log("drawing maze");
	var c=document.getElementById("myCanvas");
	var ctx=c.getContext("2d");
	var neighbours = [];

	

	for (var i=0; i<newHeight; i++)
	{
		for (var j=0; j<newWidth; j++)
		{
			neighbours=[];
			if (startY == i && startX == j)
			{
				ctx.fillStyle="#00FF00";
				ctx.fillRect(j*400/newHeight,i*400/newWidth,400/newHeight+1,400/newWidth);
			}
			else if(endY == i && endX == j)
			{
				ctx.fillStyle="#FF0000";
				ctx.fillRect(j*400/newHeight,i*400/newWidth,400/newHeight+1,400/newWidth);
			}
			else if (maze[j][i] == 'X')
			{
				neighbours = checkTile(j,i, newHeight, newWidth, maze);
				//console.log(neighbours.length);
				if (neighbours.length == 4){
					console.log("Found 4 neighbours");
					drawMiddleBlock(j,i,newHeight,newWidth,maze,neighbours);
				}
				else if (neighbours.length== 3){
					console.log("Found 3 neighbours");
					draw3neighbours(j,i,newHeight,newWidth,maze,neighbours);
				}
				else if (neighbours.length == 2){
					console.log("Found 2 neighbours");
					draw2neighbours(j,i,newHeight, newWidth, maze,neighbours);
				}
				else if (neighbours.length == 1){
					console.log("Found 1 neighbours");
					drawSingleNeighbour(j,i,newHeight,newWidth,maze,neighbours);
				}
				else {
					drawBlock(x,y,newHeight,newWidth,maze,neighbours);
				}
				//(maze)ctx.fillStyle="#0080FF";
				//ctx.fillRect(j*400/newHeight,i*400/newWidth,400/newHeight+1,400/newWidth);
			}
		}
	}
	console.log("done");
}

function draw(imgtag, x, y, height, width)
{
		var imgObj = new Image();
		imgObj.src = "../jpgs/Maze-parts/"+imgtag+".jpg";
		imgObj.onload = function()
		{
			var c=document.getElementById("myCanvas");
			var ctx=c.getContext("2d");
			//var img=document.getElementById(imgtag);
			ctx.drawImage(imgObj,x*400/height,y*400/width,400/height,400/width);
		}
}

function draw3neighbours(x,y,height,width,maze,neighbours)
{
	if (neighbours.indexOf(NORTH) != -1 && neighbours.indexOf(WEST) != -1 && neighbours.indexOf(EAST) != -1){
		console.log("Drawing TTop");
		draw("TTop", x, y, height, width);
	}
	else if (neighbours.indexOf(NORTH) != -1 && neighbours.indexOf(WEST) != -1 && neighbours.indexOf(SOUTH) != -1){
		console.log("Drawing TLeft");
		draw("TLeft", x, y, height, width);
	}
	else if (neighbours.indexOf(NORTH) != -1 && neighbours.indexOf(EAST) != -1 && neighbours.indexOf(SOUTH) != -1){
		console.log("Drawing TRight");
		draw("TRight", x, y, height, width);
	}
	else if (neighbours.indexOf(EAST) != -1 && neighbours.indexOf(WEST) != -1 && neighbours.indexOf(SOUTH) != -1){
		console.log("Drawing TBottom");
		draw("TBottom", x, y, height, width);
	}
}

function draw2neighbours(x,y,height,width,maze,neighbours)
{
	if (neighbours.indexOf(NORTH) != -1 && neighbours.indexOf(SOUTH) != -1 ){
		console.log("Drawing TopAndBottom");
		draw("TopAndBottom",x,y,height,width);
	}
	else if (neighbours.indexOf(EAST) != -1 && neighbours.indexOf(WEST) != -1 ){
		console.log("Drawing LeftAndRight");
		draw("LeftAndRight",x,y,height,width);
	}
	else if (neighbours.indexOf(NORTH) != -1 && neighbours.indexOf(WEST) != -1 ){
		console.log("Drawing BottomRightCorner");
		draw("BottomRightCorner",x,y,height,width);
	}
	else if (neighbours.indexOf(NORTH) != -1 && neighbours.indexOf(EAST) != -1 ){
		console.log("Drawing BottomLeftCorner");
		draw("BottomLeftCorner",x,y,height,width);
	}
	else if (neighbours.indexOf(SOUTH) != -1 && neighbours.indexOf(WEST) != -1 ){
		console.log("Drawing Top Right Corner");
		draw("TopRightCorner",x,y,height,width);
	}
	else if(neighbours.indexOf(SOUTH) != -1 && neighbours.indexOf(EAST) != -1 ){
		console.log("Drawing TopAndBottom");
		draw("TopLeftCorner",x,y,height,width);
	}
}

function drawSingleNeighbour(x,y,height,width,maze,neighbours)
{
	if (neighbours.indexOf(NORTH) != -1)
		draw ("Top",x,y,height,width);
	else if (neighbours.indexOf(EAST) != -1)
		draw ("Right",x,y,height,width);
	else if (neighbours.indexOf(WEST) != -1)
		draw ("Left",x,y,height,width);
	else if(neighbours.indexOf(SOUTH) != -1)
		draw ("Bottom",x,y,height,width);
}

function drawBlock (x,y,width,maze,neighbours)
{
	draw("Single",x,y,height,width);
}

function drawMiddleBlock (x,y,height, width,maze,neighbours)
{
	draw("AllSides",x,y,height,width);
}

function checkTile(x,y, height, width, maze)
{
	var i = 0;
	var neighbourWalls = [];
	if (y < height-1  && maze[x][y+1] == 'X')
		neighbourWalls[i++] = SOUTH;
	if (y != 0 && maze[x][y-1] == 'X')
		neighbourWalls[i++] = NORTH;
	if (x < width-1 && maze[x+1][y] == 'X')
		neighbourWalls[i++] = EAST;
	if (x != 0 && maze[x-1][y] == 'X')
		neighbourWalls[i++] = WEST;
	return neighbourWalls;
}

function generateMaze()
{
	if ((mazeWidth < 1) || (mazeHeight < 1))
		alert ("Invalid Maze Dimensions");
	
	var realWidth = (2*mazeWidth)+1;
	var realHeight = (2*mazeHeight)+1;
	
	mazeGrid = initialiseGrid(realWidth, realHeight);


	var neighbours = 0;
	
	for (var i=0; i<realWidth; i++)
	{
		primGrid[i] = [];
		for (var j=0; j<realHeight; j++)
			primGrid[i].push(OUT);
	}
			
	// select cell "randomly" from inside the outer walls
	var originX = realWidth - 2;
	var originY = realHeight - 2;
	
	mazeGrid = setPrimCellType(mazeGrid, originX, originY, IN);
	if (originX > 1)
		setPrimCellType(mazeGrid,originX-2,originY,FRONTIER);
	if (originY > 1)
		setPrimCellType(mazeGrid,originX,originY-2,FRONTIER);
	if (originX < primGrid.length-2)
         setPrimCellType(mazeGrid,originX+2,originY,FRONTIER);
    if (originY > primGrid[0].length-2)
         setPrimCellType(mazeGrid,originX,originY+2,FRONTIER);		// change to less than if broken
	
	// start Prim's algorithm loop
	while (frontierList.length > 0)
	{	// choose frontier point at random
		frontierPosition = Math.floor(Math.random()*frontierList.length);
		frontier = frontierList[frontierPosition];
		// add point to path
		setPrimCellType(mazeGrid, frontier[0], frontier[1], IN);
		if(frontier[0] > 1)
			if (primGrid[frontier[0]-2][frontier[1]] == OUT)
				setPrimCellType(mazeGrid, frontier[0]-2, frontier[1], FRONTIER);
		if(frontier[1] > 1)
			if (primGrid[frontier[0]][frontier[1]-2] == OUT)
				setPrimCellType(mazeGrid, frontier[0], frontier[1]-2, FRONTIER);
		if(frontier[0] < primGrid.length-2)
			if (primGrid[frontier[0]+2][frontier[1]] == OUT)
				setPrimCellType(mazeGrid,frontier[0]+2, frontier[1], FRONTIER);
		if(frontier[1] > primGrid[0].length-2)											//change to less than if broken
			if (primGrid[frontier[0]][frontier[1+2]] == OUT)
				setPrimCellType(mazeGrid, frontier[0], frontier[1]+2, FRONTIER);
	
		
		// find neighbours seperated by 1 WALL
		// max of 4
		var direction = [];
		var neighbours = 0;
		if (frontier[0]-2 > 0)
			if (primGrid[frontier[0]-2][frontier[1]] == IN)
				direction[neighbours++] = WEST;
		if (frontier[1]-2 > 0)
			if (primGrid[frontier[0]][frontier[1]-2] == IN)
				direction[neighbours++] = NORTH;
		if (frontier[0] < primGrid.length-2)
			if (primGrid[frontier[0]+2][frontier[1]] == IN)
			   direction[neighbours++] = EAST;
		if (frontier[1] < primGrid[0].length-2)
			if (primGrid[frontier[0]][frontier[1]+2] == IN)
			   direction[neighbours++] = SOUTH;
		
		// choose random neighbour
		var path = direction[Math.floor(Math.random()*neighbours)];
		for (var i; i<10; i++)
			console.log(Math.floor(Math.random()*neighbours));
		console.log(path);
		
		switch (path) {
				case NORTH: {   setPrimCellType(mazeGrid,frontier[0],frontier[1]-1,IN);
							   break;
							}
				case EAST:  {   setPrimCellType(mazeGrid,frontier[0]+1,frontier[1],IN);
							   break;
							}
				case SOUTH: {   setPrimCellType(mazeGrid,frontier[0],frontier[1]+1,IN);
							   break;
							}
				case WEST:  {  setPrimCellType(mazeGrid,frontier[0]-1,frontier[1],IN);
							}
			 }
		//console.log("Fronteier: + "+frontier[0]+" "+frontier[1]+ " removing: "+ frontierList[frontierPosition][0]+" "+frontierList[frontierPosition][1]);
		var removed = frontierList.splice(frontierPosition, 1);
		//console.log("Removed: "+ removed[0] +" "+removed[1]);
		//console.log(frontierList);
	}

	/*for (var i = 0; i<realWidth; i++)
	{
		for (var j = 0; j<realHeight; j++)
			document.write(mazeGrid[i][j] + "\t\t\t\t");
		document.write("<br>");
	}*/

	return mazeGrid;
}

function initialiseGrid(width, height)
{
	var grid = [];
	for (var i=0; i< width; i++)
	{
		grid[i] = [];
		for (var j=0; j< height; j++)
			grid[i].push(WALL);
	}
	return grid;
}

function setPrimCellType(mazeGrid, x, y, type)
{
	if (type == IN)
		mazeGrid[x][y] = PASSAGE;
	if (type == FRONTIER)
		frontierList.push([x,y]);
	primGrid[x][y] = type;
	
	return mazeGrid;
}


